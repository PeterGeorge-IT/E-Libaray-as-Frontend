
import { Book, Category } from "@/types/book";

// Mock book data
export const books: Book[] = [
  {
    id: "1",
    title: "The Digital Revolution",
    author: "Alex Turner",
    coverImage: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=1000",
    description: "An exploration of how technology has transformed our lives over the past few decades. This book delves into the social, economic, and cultural impacts of digitalization.",
    categories: ["Technology", "Non-fiction"],
    rating: 4.5,
    pageCount: 320,
    language: "English",
    publicationDate: "2022-04-15",
    isFeatured: true,
    isAvailable: true
  },
  {
    id: "2",
    title: "Echoes of Eternity",
    author: "Sophia Chen",
    coverImage: "https://images.unsplash.com/photo-1518744386442-2d48ac47a7eb?auto=format&fit=crop&q=80&w=1000",
    description: "A captivating science fiction novel set in the 23rd century where humanity has achieved immortality through digital consciousness transfer.",
    categories: ["Science Fiction", "Adventure"],
    rating: 4.7,
    pageCount: 480,
    language: "English",
    publicationDate: "2023-02-10",
    isFeatured: true,
    isAvailable: true
  },
  {
    id: "3",
    title: "The Art of Data",
    author: "Marcus Johnson",
    coverImage: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=1000",
    description: "A comprehensive guide to data visualization and interpretation in the modern age. Perfect for both beginners and experienced data analysts.",
    categories: ["Technology", "Education"],
    rating: 4.2,
    pageCount: 256,
    language: "English",
    publicationDate: "2021-11-30",
    isFeatured: false,
    isAvailable: true
  },
  {
    id: "4",
    title: "Midnight Whispers",
    author: "Elena Blackwood",
    coverImage: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=1000",
    description: "A thrilling mystery novel that follows detective Sarah Miles as she uncovers a series of secrets in a small coastal town.",
    categories: ["Mystery", "Thriller"],
    rating: 4.8,
    pageCount: 384,
    language: "English",
    publicationDate: "2023-07-22",
    isFeatured: true,
    isAvailable: true
  },
  {
    id: "5",
    title: "Foundations of AI",
    author: "Dr. Robert Lee",
    coverImage: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80&w=1000",
    description: "An accessible introduction to artificial intelligence concepts, history, and future implications for society and business.",
    categories: ["Technology", "Education"],
    rating: 4.6,
    pageCount: 420,
    language: "English",
    publicationDate: "2022-09-05",
    isFeatured: false,
    isAvailable: true
  },
  {
    id: "6",
    title: "The Historical Atlas",
    author: "Prof. Jennifer Adams",
    coverImage: "https://images.unsplash.com/photo-1535905557558-afc4877a26fc?auto=format&fit=crop&q=80&w=1000",
    description: "A beautifully illustrated atlas that chronicles human history from ancient civilizations to the modern day through maps and informative text.",
    categories: ["History", "Reference"],
    rating: 4.9,
    pageCount: 512,
    language: "English",
    publicationDate: "2021-05-18",
    isFeatured: true,
    isAvailable: true
  },
  {
    id: "7",
    title: "Beyond the Horizon",
    author: "Michael Rivera",
    coverImage: "https://images.unsplash.com/photo-1503830481035-595a337028c2?auto=format&fit=crop&q=80&w=1000",
    description: "A profound philosophical journey that explores the meaning of existence and humanity's place in the cosmos.",
    categories: ["Philosophy", "Non-fiction"],
    rating: 4.3,
    pageCount: 298,
    language: "English",
    publicationDate: "2022-12-01",
    isFeatured: false,
    isAvailable: true
  },
  {
    id: "8",
    title: "The Quantum Paradox",
    author: "Dr. Samantha Wells",
    coverImage: "https://images.unsplash.com/photo-1614332287897-cdc485fa562d?auto=format&fit=crop&q=80&w=1000",
    description: "A fascinating exploration of quantum physics and its mind-bending implications for our understanding of reality.",
    categories: ["Science", "Physics"],
    rating: 4.7,
    pageCount: 340,
    language: "English",
    publicationDate: "2023-03-28",
    isFeatured: true,
    isAvailable: true
  }
];

// Mock categories
export const categories: Category[] = [
  { id: "1", name: "Technology", slug: "technology", bookCount: 3 },
  { id: "2", name: "Science Fiction", slug: "science-fiction", bookCount: 1 },
  { id: "3", name: "Mystery", slug: "mystery", bookCount: 1 },
  { id: "4", name: "History", slug: "history", bookCount: 1 },
  { id: "5", name: "Philosophy", slug: "philosophy", bookCount: 1 },
  { id: "6", name: "Science", slug: "science", bookCount: 1 },
  { id: "7", name: "Non-fiction", slug: "non-fiction", bookCount: 2 },
  { id: "8", name: "Education", slug: "education", bookCount: 2 },
  { id: "9", name: "Adventure", slug: "adventure", bookCount: 1 },
  { id: "10", name: "Thriller", slug: "thriller", bookCount: 1 },
  { id: "11", name: "Physics", slug: "physics", bookCount: 1 },
  { id: "12", name: "Reference", slug: "reference", bookCount: 1 }
];

// Get featured books
export const getFeaturedBooks = (): Book[] => {
  return books.filter(book => book.isFeatured);
};

// Get book by ID
export const getBookById = (id: string): Book | undefined => {
  return books.find(book => book.id === id);
};

// Get books by category
export const getBooksByCategory = (categorySlug: string): Book[] => {
  const category = categories.find(cat => cat.slug === categorySlug);
  if (!category) return [];
  return books.filter(book => book.categories.includes(category.name));
};

// Search books
export const searchBooks = (query: string): Book[] => {
  const lowercaseQuery = query.toLowerCase();
  return books.filter(
    book =>
      book.title.toLowerCase().includes(lowercaseQuery) ||
      book.author.toLowerCase().includes(lowercaseQuery) ||
      book.description.toLowerCase().includes(lowercaseQuery)
  );
};
