
import { useEffect, useState } from "react";
import { Book } from "@/types/book";
import { getFeaturedBooks } from "@/data/mockBooks";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const FeaturedBooks = () => {
  const [featuredBooks, setFeaturedBooks] = useState<Book[]>([]);
  const [currentBookIndex, setCurrentBookIndex] = useState(0);
  
  useEffect(() => {
    const books = getFeaturedBooks();
    setFeaturedBooks(books);
  }, []);
  
  useEffect(() => {
    // Auto-rotate featured books every 8 seconds
    const interval = setInterval(() => {
      setCurrentBookIndex((prevIndex) => 
        prevIndex === featuredBooks.length - 1 ? 0 : prevIndex + 1
      );
    }, 8000);
    
    return () => clearInterval(interval);
  }, [featuredBooks.length]);
  
  if (featuredBooks.length === 0) return null;
  
  const currentBook = featuredBooks[currentBookIndex];
  
  return (
    <section className="relative h-[500px] md:h-[600px] bg-elibrary-bg-dark overflow-hidden">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{ backgroundImage: `url(${currentBook.coverImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-elibrary-bg-dark via-elibrary-bg-dark/80 to-transparent"></div>
      </div>
      
      {/* Content */}
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
              {currentBook.title}
            </h1>
            <p className="text-xl text-gray-300">by {currentBook.author}</p>
            <div className="max-w-xl">
              <p className="text-gray-400 line-clamp-3">{currentBook.description}</p>
            </div>
            <div className="flex items-center space-x-4 pt-4">
              <Button asChild className="bg-elibrary-accent hover:bg-elibrary-accent-dark text-white">
                <Link to={`/book/${currentBook.id}`}>Read Now</Link>
              </Button>
              <Button asChild variant="outline" className="border-elibrary-accent text-elibrary-accent">
                <Link to="/library">Browse Library</Link>
              </Button>
            </div>
          </div>
          
          <div className="hidden md:block relative h-[400px] w-[280px] mx-auto">
            <img 
              src={currentBook.coverImage} 
              alt={currentBook.title} 
              className="absolute inset-0 w-full h-full object-cover rounded-lg shadow-2xl transform -rotate-3 animate-fade-in"
              style={{ animationDelay: "300ms" }}
            />
          </div>
        </div>
      </div>
      
      {/* Book selector indicators */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center space-x-2">
        {featuredBooks.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentBookIndex(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentBookIndex ? "bg-elibrary-accent w-8" : "bg-white/30"
            }`}
            aria-label={`Go to featured book ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
};

export default FeaturedBooks;
